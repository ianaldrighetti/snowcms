<?php
//                 SnowCMS
//           By aldo and soren121
//  Founded by soren121 & co-founded by aldo
//    http://snowcms.northsalemcrew.net
//
// SnowCMS is released under the GPL v3 License
// Which means you are free to edit it and then
//       redistribute it as your wish!
// 
//              Core.php file 


if(!defined("Snow"))
  die("Hacking Attempt...");

function loadSettings() {
global $db_prefix;
  $result = mysql_query("SELECT * FROM {$db_prefix}settings");
    while($row = mysql_fetch_assoc($result)) 
      $settings[$row['variable']] = $row['value'];
  return $settings;
}  

function loadUser() {
global $db_prefix;
  $user = array();
  // Set some default info, incase they are guests
  $user['id'] = 0;
  $user['group'] = 0;
  $user['is_logged'] = false;
  $user['is_guest'] = true;
  $user['name'] = null;
  $user['email'] = null;
  if(isset($_SESSION['id'])) {
    if(isset($_SESSION['pass'])) {
      $result = mysql_query("SELECT * FROM {$db_prefix}members WHERE `id` = '{$_SESSION['id']}' AND `pass` = '{$_SESSION['pass']}'");
      if(mysql_num_rows($result)>0) {
        while($row = mysql_fetch_assoc($result)) {
          $user = array(
            'id' => $row['id'],
            'name' => $row['display_name'] ? $row['display_name'] : $row['user_name'],
            'group' => $row['group'],
            'is_logged' => true,
            'is_guest' => false,
            'email' => $row['email']
          );
        }
      }
    }
  }
  return $user;
}

function loadLanguage() {
global $settings;
  $l = array();
  print_r($settings);
}

function loadTheme() {

}
?>