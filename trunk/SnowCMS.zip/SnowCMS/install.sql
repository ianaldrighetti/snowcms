create table `scms_settings` (
  `variable` text not null,
  `value` text not null
) ENGINE=MyISAM
insert into `scms_settings` VALUES('site_name','SnowCMS');
insert into `scms_settings` values('slogan','Its a CMS all right...');